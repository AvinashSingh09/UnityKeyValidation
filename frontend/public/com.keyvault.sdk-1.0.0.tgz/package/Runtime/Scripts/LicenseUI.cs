using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

namespace KeyVault.SDK
{
    /// <summary>
    /// UI manager for license key activation.
    /// Supports both manually created Unity Canvas UI (recommended) and a built-in IMGUI fallback.
    /// </summary>
    public class LicenseUI : MonoBehaviour
    {
        [Header("Manual Canvas UI (Recommended)")]
        [Tooltip("Canvas or GameObject containing the key input field and verify button.")]
        [SerializeField] private GameObject verificationCanvas;


        [Tooltip("Canvas or GameObject shown after successful key verification.")]
        [SerializeField] private GameObject welcomeCanvas;


        [Tooltip("The TMPro Input Field where the user enters the license key.")]
        [SerializeField] private TMP_InputField keyInputField;


        [Tooltip("The Button that triggers verification.")]
        [SerializeField] private Button verifyButton;


        [Tooltip("The Button inside the Welcome Canvas that continues the game/app.")]
        [SerializeField] private Button welcomeOkButton;


        [Tooltip("Optional TMPro Text component to display validation status or error messages.")]
        [SerializeField] private TextMeshProUGUI statusText;

        [Header("State (Read Only)")]
        [SerializeField] private bool _isProcessing = false;
        [SerializeField] private string _statusMessage = "";

        // IMGUI Legacy Fallback Variables
        private string _inputKey = "";
        private bool _showIMGUI = false;
        private GUIStyle _boxStyle;
        private GUIStyle _titleStyle;
        private GUIStyle _buttonStyle;
        private GUIStyle _inputStyle;
        private GUIStyle _statusStyle;
        private bool _stylesInitialized = false;

        private void Start()
        {
            // Subscribe to licensing state change event
            if (KeyValidator.Instance != null)
            {
                KeyValidator.Instance.OnLicenseStateChanged += OnLicenseStateChanged;
            }

            // Setup button listeners if assigned
            if (verifyButton != null)
            {
                verifyButton.onClick.AddListener(OnVerifyButtonClicked);
            }
            if (welcomeOkButton != null)
            {
                welcomeOkButton.onClick.AddListener(OnWelcomeOkButtonClicked);
            }

            // Setup input field submit/enter key action if assigned
            if (keyInputField != null)
            {
                keyInputField.onSubmit.AddListener(delegate { OnVerifyButtonClicked(); });
            }

            // Initialize UI state
            RefreshUI();
        }

        private void OnDestroy()
        {
            if (KeyValidator.Instance != null)
            {
                KeyValidator.Instance.OnLicenseStateChanged -= OnLicenseStateChanged;
            }
        }

        private void RefreshUI()
        {
            if (KeyValidator.Instance == null) return;

            bool isLicensed = KeyValidator.Instance.IsLicensed;

            // Check if we are using the Canvas UI
            bool usingCanvasUI = (verificationCanvas != null && keyInputField != null && verifyButton != null);

            if (usingCanvasUI)
            {
                _showIMGUI = false;

                if (isLicensed)
                {
                    verificationCanvas.SetActive(false);
                    if (welcomeCanvas != null) welcomeCanvas.SetActive(true);
                }
                else
                {
                    // If not licensed, show verification UI
                    verificationCanvas.SetActive(true);
                    if (welcomeCanvas != null) welcomeCanvas.SetActive(false);
                }
            }
            else
            {
                // Fallback to legacy IMGUI
                _showIMGUI = !isLicensed;
            }
        }

        private void OnLicenseStateChanged(bool isLicensed, string reason)
        {
            RefreshUI();
        }

        private void OnVerifyButtonClicked()
        {
            if (_isProcessing || keyInputField == null) return;

            string key = keyInputField.text.Trim();
            if (string.IsNullOrEmpty(key))
            {
                UpdateStatusText("❌ Key cannot be empty", true);
                return;
            }

            SetInteractiveState(false);
            UpdateStatusText("Validating...", false);

            KeyValidator.Instance.Activate(key, (success, message) =>
            {
                SetInteractiveState(true);

                if (success)
                {
                    UpdateStatusText("✅ Verified!", false);
                    if (verificationCanvas != null) verificationCanvas.SetActive(false);
                    if (welcomeCanvas != null) welcomeCanvas.SetActive(true);
                }
                else
                {
                    UpdateStatusText($"❌ {message}", true);
                }
            });
        }

        private void OnWelcomeOkButtonClicked()
        {
            SceneManager.LoadScene(1);
        }

        private void SetInteractiveState(bool interactive)
        {
            _isProcessing = !interactive;
            if (verifyButton != null) verifyButton.interactable = interactive;
            if (keyInputField != null) keyInputField.interactable = interactive;
        }

        private void UpdateStatusText(string message, bool isError)
        {
            _statusMessage = message;
            if (statusText != null)
            {
                statusText.text = message;
                statusText.color = isError ? Color.red : Color.green;
            }
        }

        // ─── Legacy IMGUI Fallback Implementation ───

        private void InitStyles()
        {
            if (_stylesInitialized) return;

            _boxStyle = new GUIStyle(GUI.skin.box);
            _boxStyle.padding = new RectOffset(30, 30, 30, 30);
            _boxStyle.normal.background = MakeTexture(2, 2, new Color(0.1f, 0.1f, 0.15f, 0.95f));

            _titleStyle = new GUIStyle(GUI.skin.label);
            _titleStyle.fontSize = 22;
            _titleStyle.fontStyle = FontStyle.Bold;
            _titleStyle.alignment = TextAnchor.MiddleCenter;
            _titleStyle.normal.textColor = Color.white;

            _buttonStyle = new GUIStyle(GUI.skin.button);
            _buttonStyle.fontSize = 14;
            _buttonStyle.fixedHeight = 40;
            _buttonStyle.normal.textColor = Color.white;
            _buttonStyle.normal.background = MakeTexture(2, 2, new Color(0.39f, 0.4f, 0.95f, 1f));

            _inputStyle = new GUIStyle(GUI.skin.textField);
            _inputStyle.fontSize = 16;
            _inputStyle.fixedHeight = 36;
            _inputStyle.alignment = TextAnchor.MiddleCenter;

            _statusStyle = new GUIStyle(GUI.skin.label);
            _statusStyle.fontSize = 12;
            _statusStyle.alignment = TextAnchor.MiddleCenter;
            _statusStyle.normal.textColor = new Color(1f, 0.5f, 0.5f, 1f);

            _stylesInitialized = true;
        }

        private void OnGUI()
        {
            if (!_showIMGUI || KeyValidator.Instance == null) return;

            InitStyles();

            float width = 440;
            float height = 260;
            Rect windowRect = new Rect(
                (Screen.width - width) / 2,
                (Screen.height - height) / 2,
                width, height
            );

            // Dim background
            GUI.DrawTexture(new Rect(0, 0, Screen.width, Screen.height),
                MakeTexture(1, 1, new Color(0, 0, 0, 0.7f)));

            GUILayout.BeginArea(windowRect, _boxStyle);

            GUILayout.Label("🔑 License Activation", _titleStyle);
            GUILayout.Space(20);

            GUILayout.Label("Enter your license key:", GUI.skin.label);
            GUILayout.Space(5);

            _inputKey = GUILayout.TextField(_inputKey, _inputStyle);
            GUILayout.Space(15);

            GUI.enabled = !_isProcessing && !string.IsNullOrEmpty(_inputKey);

            if (GUILayout.Button(_isProcessing ? "Validating..." : "Activate License", _buttonStyle))
            {
                _isProcessing = true;
                _statusMessage = "Validating...";

                KeyValidator.Instance.Activate(_inputKey.Trim(), (success, message) =>
                {
                    _isProcessing = false;
                    _statusMessage = success ? "✅ License activated!" : $"❌ {message}";
                });
            }

            GUI.enabled = true;

            if (!string.IsNullOrEmpty(_statusMessage))
            {
                GUILayout.Space(10);
                GUILayout.Label(_statusMessage, _statusStyle);
            }

            GUILayout.EndArea();
        }

        private Texture2D MakeTexture(int width, int height, Color color)
        {
            Color[] pixels = new Color[width * height];
            for (int i = 0; i < pixels.Length; i++)
                pixels[i] = color;

            Texture2D texture = new Texture2D(width, height);
            texture.SetPixels(pixels);
            texture.Apply();
            return texture;
        }
    }
}
